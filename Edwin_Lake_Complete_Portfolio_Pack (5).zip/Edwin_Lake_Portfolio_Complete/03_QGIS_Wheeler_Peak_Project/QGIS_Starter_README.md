# 2D & 3D Terrain Mapping with QGIS — Starter Project

**Portfolio owner:** Edwin Lake  
**Project type:** GIS workflow / reproducible mapping  
**Status:** Starter project — complete the workflow and replace placeholders with your own outputs before describing results as completed.

## Objective

Create a 2D elevation map and a 3D terrain visualization from a real public Digital Elevation Model (DEM), then document the study area, data source, coordinate reference system, processing steps, and limitations.

## Suggested study area

Choose a manageable area you can explain clearly. This starter does not assume a location or claim that analysis has already been completed. Record your chosen area and coordinates after downloading the data.

## Data source

Use a public DEM from the USGS EarthExplorer / 3DEP portal or another suitable authoritative source. Record the dataset title, resolution, download date, source URL, and any license/attribution requirements.

- USGS EarthExplorer: https://earthexplorer.usgs.gov/
- USGS 3D Elevation Program: https://www.usgs.gov/3d-elevation-program
- QGIS documentation: https://docs.qgis.org/

If you are working in Nigeria, confirm that the selected dataset actually covers your chosen Nigerian study area and check the dataset's resolution and terms. Do not assume a US-specific elevation service covers Nigeria.

## Workflow in QGIS

1. Download a DEM for your chosen study area from a suitable public source.
2. Open QGIS and add the DEM raster layer.
3. Check its CRS, pixel size, elevation units, NoData value, and geographic coverage.
4. Clip the raster to a clearly defined study boundary if needed.
5. Create a 2D elevation map:
   - Open **Layer Properties → Symbology**.
   - Use **Singleband pseudocolor**.
   - Select an appropriate continuous color ramp.
   - Add a legend, scale bar, north arrow, map title, data source, and CRS in a Print Layout.
6. Create hillshade (optional):
   - Use **Processing Toolbox → GDAL → Raster terrain analysis → Hillshade**.
   - Record the parameters used. Consider overlaying a semi-transparent hillshade over the elevation raster.
7. Create a 3D view:
   - Open **View → New 3D Map View** (menu wording may vary by QGIS version).
   - Configure the DEM as the terrain elevation source.
   - Adjust vertical scale and lighting cautiously; record any exaggeration.
   - Save a clear screenshot with scale/context and layer names visible where practical.
8. Export the 2D layout and save a screenshot of the 3D view.
9. Write a short interpretation based only on visible terrain patterns and verified metadata. Avoid claims about a “best” site or hazard unless you run and document a suitable analysis.

## Evidence to save

Place your own files in this folder structure:

```text
outputs/
  elevation_map_2d.png
  terrain_view_3d.png
  optional_hillshade.png
```

Use meaningful filenames and ensure the images come from your own QGIS project. Do not use illustrative mockups as if they were screenshots from your software.

## Project report template

### Study area
[Name the area and explain why you selected it.]

### Data
[Dataset name, provider, resolution, CRS, units, download date, and license.]

### Methods
[Describe clipping, symbology, hillshade settings, 3D terrain configuration, and software version.]

### Observations
[Describe only patterns that you can directly see and support from your map.]

### Limitations
[State resolution limits, missing data, vertical exaggeration, scale constraints, and anything else relevant.]

### Reproducibility
- QGIS version: [fill in]
- DEM source: [fill in]
- CRS: [fill in]
- Processing parameters: [fill in]
- Export date: [fill in]

## Suggested GitHub repository description

`A reproducible QGIS workflow for creating a 2D elevation map and 3D terrain visualization from public DEM data.`

## Suggested portfolio caption

> Built a QGIS workflow to visualize public elevation data in 2D and 3D. The project documents the DEM source, CRS, raster styling, terrain visualization settings, and limitations. Maps and observations are based on the selected dataset and are documented in the repository.

**Important:** This README is a project starter, not evidence that the workflow has already been executed. Update the status and add your real maps and observations after completing the work.
