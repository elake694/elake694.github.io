# EDWIN LAKE — PORTFOLIO PACK

**Portfolio materials status:** ORGANIZED AND LABELLED  
**GIS case study status:** IN PROGRESS — real DEM processing and QGIS exports still required

## Folder guide

| Folder | Label | What it contains | Publish status |
|---|---|---|---|
| `01_GitHub_Profile/` | **PROFILE README** | GitHub profile README with background, skills, and contact links | Ready to review and upload |
| `02_Portfolio_Website/` | **PORTFOLIO WEBSITE** | `index.html`, project README template, and publishing notes | Starter website; review links and publish |
| `03_QGIS_Wheeler_Peak_Project/` | **GIS CASE STUDY — IN PROGRESS** | Project brief PDF, README, workflow checklist, and starter notes | Do not label as completed analysis yet |
| `04_Resume/` | **RESUME — PRIVATE REVIEW FIRST** | Original resume PDF | Redact home address and personal phone details before public upload |
| `05_Visual_Reference/` | **ILLUSTRATIVE MOCKUP — NOT REAL RESULTS** | Conceptual GIS visual reference | Inspiration only; not evidence of completed GIS work |

## What is finished in this pack

- Portfolio files have been collected into clearly labelled folders.
- GitHub profile README and static website files are included.
- The Wheeler Peak GIS case-study brief, README, and workflow checklist are included.
- The original resume is included for review.
- The illustrative visual is explicitly labelled as a mockup.

## What is not yet complete

The real Wheeler Peak terrain analysis has **not** been run. No real DEM was downloaded or processed in QGIS in this session, so there is no verified Wheeler Peak `.qgz` project, derived hillshade/slope/aspect raster, final map export, or genuine QGIS screenshot in this pack. These must not be claimed as completed work.

To finish the GIS case study, download a real elevation DEM from the [USGS National Map Downloader](https://apps.nationalmap.gov/downloader/) or another verified source, record its metadata and license, process it in QGIS, and add the resulting map exports and project file. QGIS documentation explains how to derive hillshade and slope from a DEM: https://docs.qgis.org/3.44/en/docs/user_manual/processing_algs/qgis/rasterterrainanalysis.html

## Recommended public-upload order

1. Upload `01_GitHub_Profile/README.md` to the repository named exactly `elake694`.
2. Upload the contents of `02_Portfolio_Website/` to the GitHub Pages repository, checking the links and contact details before publishing.
3. Publish a **redacted** resume PDF only after checking the original for private contact details.
4. Publish the Wheeler Peak folder as an **in-progress case study** until real GIS outputs have been generated and verified.
5. Do not publish the mockup as a real result. If you keep it online, retain the `NOT REAL RESULTS` label.

## Profile links

- GitHub: https://github.com/elake694
- Portfolio website: https://elake694.github.io
- LinkedIn: https://www.linkedin.com/in/edwin-lake-0424741a/
- Professional portfolio email: edwinlake239@gmail.com
