# [Project Title]

> One sentence explaining the question or problem this project addresses.

## Overview
- **Project area:** [Data analysis / GIS / rock analysis / other]
- **Objective:** [What the project set out to do]
- **Tools used:** [Only tools actually used]
- **Status:** [Completed / In progress / Planned]

## Context and question
[Explain the problem and why it matters.]

## Data, samples, or inputs
[Describe datasets, samples, source, time period, spatial coverage, and any sharing restrictions.]

## Methods / workflow
1. **Preparation:** [Cleaning, validation, or preprocessing]
2. **Analysis:** [Statistical, geological, spatial, or technical methods actually applied]
3. **Validation:** [Checks, assumptions, or quality-control steps]
4. **Outputs:** [Maps, charts, tables, models, drawings, or other deliverables]

## Evidence
Add screenshots, figures, or video links that genuinely come from the project. Caption each item with what it demonstrates. For maps, include scale and legend where useful, data source, and coordinate reference system. For engineering drawings, use actual verified dimensions and tolerances.

## Results
- [Verified result 1]
- [Verified result 2]
- [Interpretation supported by the evidence]

Do not invent findings or fill this section with expected results. If analysis is not yet complete, state that clearly.

## Limitations
[Data gaps, assumptions, sample constraints, spatial resolution, uncertainty, or other limits.]

## Reproducibility
[Steps to reproduce the workflow, software versions, dependencies, CRS, or other relevant settings.]

## Files
```text
project-name/
├── README.md
├── data/       # only if permitted to share
├── figures/
├── scripts/    # if applicable
├── notebooks/  # if applicable
└── outputs/
```

## Author
Edwin Lake · [GitHub](https://github.com/Edwinlake39) · [LinkedIn](https://www.linkedin.com/in/edwin-lake-0424741a/) · [Email](mailto:edwinlake239@gmail.com)
