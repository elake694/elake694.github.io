# Edwin Lake — Data Analysis & GIS Portfolio Setup

## Files
- `index.html` — personalized website homepage.
- `profile_README.md` — content for your GitHub profile README.
- `project_README_template.md` — reusable template for project repositories.

## Publish the website
1. Sign in to GitHub as `Edwinlake39`.
2. Create a **public** repository named exactly `Edwinlake39.github.io`.
3. Upload `index.html` to the repository's top level and commit.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch `main` and folder `/(root)`, then save.
7. After publishing finishes, open https://Edwinlake39.github.io/

Official guide: https://docs.github.com/en/pages/quickstart

## Publish the profile README
1. Create a public repository named exactly `Edwinlake39`.
2. Add a `README.md` file.
3. Copy the content from `profile_README.md` into it and commit.

If the repository `Edwinlake39` already exists, add or update its README rather than creating a duplicate.

## Before publishing
- Add direct repository URLs for each real project.
- Replace placeholders with actual methods, data sources, results, and screenshots.
- Do not claim a landing zone is optimal unless the slope analysis and criteria support that conclusion.
- Include only software you actually used for each project.
- Keep confidential data, respondent identifiers, passwords, API keys, and restricted datasets out of public repositories.
- The rover CAD/electronics/game/audio/video evidence is marked as optional and should be included only if it represents your work. Distinguish completed, in-progress, and planned deliverables.
