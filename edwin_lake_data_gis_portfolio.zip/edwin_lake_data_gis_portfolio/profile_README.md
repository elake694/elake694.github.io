# Hi, I'm Edwin Lake 👋

### Data Analysis | GIS | Research & Visualization

I work across data analysis, geospatial mapping, and research. My project areas include **indigenous knowledge and environmental conservation in cocoa farming, rock analysis, and 2D/3D mapping**.

I use tools including **SPSS, Excel, Python, SQL, Tableau, QGIS, and ArcGIS** to organize data, analyze questions, and communicate evidence through clear outputs.

- 🌍 **Portfolio website:** https://Edwinlake39.github.io/
- 💻 **GitHub:** https://github.com/Edwinlake39
- 💼 **LinkedIn:** https://www.linkedin.com/in/edwin-lake-0424741a/
- 📧 **Email:** edwinlake239@gmail.com

---

## Featured Projects

### 1. Indigenous Knowledge & Environmental Conservation in Cocoa Farming
A research project focused on indigenous environmental conservation practices used in cocoa farming.

**Portfolio evidence to include**
- Research objectives and questions
- Description of the dataset and variables, subject to privacy and data-sharing restrictions
- Data cleaning and statistical workflow
- Tables or visualizations generated from the actual analysis
- Verified findings, limitations, and evidence-based recommendations

**Tools:** SPSS, Excel (list only the tools actually used for this project)  
**Repository:** [Add the direct project repository link when available]

### 2. Rock Analysis
A technical project focused on rock analysis.

**Portfolio evidence to include**
- Project objective and description of the samples or data
- Methods, measurements, and tools actually used
- Images, tables, plots, or other records supporting the analysis
- Findings and conclusions supported by the project evidence

**Tools:** [Add the actual software and methods used]  
**Repository:** [Add the direct project repository link when available]

### 3. 2D & 3D Mapping with QGIS / ArcGIS
A GIS project showcasing 2D mapping and 3D terrain visualization.

**Portfolio evidence to include**
- Side-by-side screenshot of a 2D topographic map and a 3D digital elevation model (DEM) exported from QGIS
- Study area, data sources, coordinate reference system, and processing workflow
- If applicable to the completed work: a documented raster-slope workflow for evaluating rover landing-zone suitability
- Map exports, interpretation, and limitations

**Tools:** QGIS 3.x, ArcGIS (identify which tool was used for each output)  
**Repository:** [Add the direct project repository link when available]

---

## Technical Skills

**Data analysis & visualization:** SPSS, Microsoft Excel, Python, SQL, Tableau  
**GIS:** QGIS 3.x, ArcGIS  
**Geospatial interests:** 2D cartography, 3D terrain visualization, raster analysis  
**Project documentation:** Data sources, methods, visual evidence, findings, and limitations

## Additional Technical Showcase — Include If Applicable

If the rover development work described in my project notes is part of my own work, I can document it as a separate multidisciplinary case study. Evidence may include:

- **GIS / terrain:** 2D topographic map, 3D DEM, and documented slope analysis.
- **Mechanical CAD:** exploded-view animation of chassis, suspension, and camera gimbal; dimensioned engineering drawing.
- **Electronics:** PCB schematic and 3D board render.
- **2D / 3D art:** concept sketches, wireframe, and Base Color, Roughness, and Normal texture maps.
- **Game development:** short gameplay clip paired with the physics or script architecture.
- **Audio:** sound-design breakdown showing the individual audio layers.
- **Video:** 60–90 second developer breakdown with workflow callouts and voiceover.

For each item, name the software actually used, link to evidence where shareable, and state whether it is completed, in progress, or planned. Do not present proposed evidence as completed work.

---

## My Project Workflow

1. Define the problem and intended output.
2. Record data sources, assumptions, and limitations.
3. Prepare and validate data.
4. Apply methods appropriate to the question.
5. Present findings through maps, charts, tables, or technical visuals.
6. Document what the evidence supports and what remains uncertain.

---

*This profile is a portfolio starting point. Add direct repository links, screenshots, and verified results as you publish each project.*
