# Wheeler Peak, New Mexico — 2D & 3D Terrain Mapping

**Portfolio owner:** Edwin Lake  
**Tools:** QGIS, USGS 3DEP elevation data  
**Project status:** Planned workflow / not yet executed in QGIS

## Objective
Create a clear 2D elevation map and 3D terrain view from a public Digital Elevation Model (DEM) for the Wheeler Peak area of New Mexico, USA.

## Data source
- USGS The National Map Downloader: https://apps.nationalmap.gov/downloader/
- USGS 3D Elevation Program: https://www.usgs.gov/3d-elevation-program
- USGS public-domain Wheeler Peak DEM visualization example: https://www.usgs.gov/media/images/3dep-dem-viewer-visualizations-wheeler-peak-new-mexico-nm
- QGIS 3D Map View documentation: https://docs.qgis.org/3.44/en/docs/user_manual/map_views/3d_map_view.html

Select a DEM that covers the chosen study area. Prefer a 1/3 arc-second (~10 m) product if available; otherwise use a suitable 1 arc-second (~30 m) product. Verify the exact product title, resolution, CRS, vertical units, source, and download date from its metadata. These details are intentionally left blank until the actual file is selected.

## Workflow
1. Download the DEM for a small area around Wheeler Peak.
2. Load it into QGIS and inspect CRS, pixel size, units, and NoData values.
3. Style the raster using Singleband pseudocolor.
4. Generate a hillshade with Processing Toolbox and optionally overlay it at reduced opacity.
5. Build a Print Layout with map title, legend, scale bar, north arrow, data source, and CRS.
6. Open View → 3D Map Views → New 3D Map View; configure the DEM as the terrain elevation source.
7. Keep vertical scale at 1 initially; document any exaggeration used.
8. Export the 2D layout and 3D view from QGIS.
9. Replace the evidence placeholders and fill the metadata section below based on the actual data.

## Data metadata — complete after download
- DEM product/title: [fill in]
- Provider and source URL: [fill in]
- Download date: [fill in]
- Horizontal CRS: [fill in]
- Vertical units/datum: [fill in]
- Cell size/resolution: [fill in]
- QGIS version: [fill in]
- Processing parameters: [fill in]

## Outputs to add
- `outputs/wheeler_peak_2d_elevation.png`
- `outputs/wheeler_peak_3d_terrain.png`
- `Wheeler_Peak_Terrain.qgz`

## Interpretation and limitations
Only report terrain patterns that you have observed in the downloaded data. State the DEM resolution, vertical units/datum if known, and any resampling or vertical exaggeration. Do not make claims about landslide risk, safest landing sites, or optimal locations without a separate documented analysis.

## Portfolio caption
> Planned a reproducible QGIS workflow to visualize public USGS elevation data in 2D and 3D. The project documents data provenance, coordinate reference system, raster styling, hillshade parameters, 3D terrain settings, and limitations. Final maps and observations will be added after processing the selected DEM in QGIS.
