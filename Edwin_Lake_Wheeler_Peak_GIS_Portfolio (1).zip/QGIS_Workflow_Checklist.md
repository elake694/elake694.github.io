# QGIS Workflow Checklist — Wheeler Peak, New Mexico

## Before QGIS
- [ ] Open https://apps.nationalmap.gov/downloader/
- [ ] Search for Wheeler Peak, New Mexico, and define a small study-area rectangle.
- [ ] Choose Elevation Products (3DEP).
- [ ] Select 1/3 arc-second DEM if available, otherwise an appropriate 1 arc-second DEM.
- [ ] Download the data and preserve its metadata / product name.
- [ ] Extract the archive if it is zipped.

## Load and inspect
- [ ] Open QGIS and create a new project.
- [ ] Drag the DEM GeoTIFF into the map canvas.
- [ ] Right-click DEM → Zoom to Layer.
- [ ] Open Layer Properties → Information; record CRS, pixel size, bands, and NoData.
- [ ] Save as `Wheeler_Peak_Terrain.qgz`.

## 2D map
- [ ] Layer Properties → Symbology → Singleband pseudocolor.
- [ ] Choose a clear continuous elevation color ramp and classify.
- [ ] Processing Toolbox → search `Hillshade`; run using the DEM.
- [ ] Optionally place hillshade above the colored DEM and reduce opacity.
- [ ] Project → New Print Layout.
- [ ] Add map, title, legend, scale bar, north arrow, data source, CRS, and author.
- [ ] Export `outputs/wheeler_peak_2d_elevation.png`.

## 3D terrain
- [ ] View → 3D Map Views → New 3D Map View.
- [ ] Open configuration and set Terrain type to DEM / Raster Layer.
- [ ] Select the downloaded DEM as the elevation layer.
- [ ] Start with vertical scale 1.0.
- [ ] Adjust camera and framing for a clear terrain perspective.
- [ ] Save the QGIS project.
- [ ] Use the 3D view Export → Save as Image if available, or take a screenshot.
- [ ] Save as `outputs/wheeler_peak_3d_terrain.png`.

## Final quality check
- [ ] Add genuine exported images to `outputs/`.
- [ ] Fill in dataset title, resolution, CRS, units, download date, and QGIS version in README.md.
- [ ] Write only observations supported by your actual data.
- [ ] Note any vertical exaggeration and limitations.
